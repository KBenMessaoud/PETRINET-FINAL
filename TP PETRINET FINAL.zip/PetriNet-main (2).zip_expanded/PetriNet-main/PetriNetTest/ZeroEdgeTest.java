package PetriNetTest;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import PetriNet.Place;
import PetriNet.ZeroEdge;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class ZeroEdgeTest {

    private ZeroEdge zeroEdge;
    private Place place;

    @BeforeEach
    public void setup() {
        place = new Place("P1", 0);  
        zeroEdge = new ZeroEdge(1);  
        zeroEdge.setPlace(place);    
    }

    @Test
    public void testIsTriggerableWithZeroTokens() {
        assertTrue(zeroEdge.isTriggerable(), "Should be triggerable when place has zero tokens");
    }

    @Test
    public void testIsTriggerableWithMoreTokens() {
        place.add(5);  
        assertFalse(zeroEdge.isTriggerable(), "Should not be triggerable when place has more than zero tokens");
    }

   

    
}
