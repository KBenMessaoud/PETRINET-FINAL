package PetriNetTest;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import PetriNet.InEdge;
import PetriNet.OutEdge;
import PetriNet.Transition;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class TransitionTest {

    private Transition transition;
    private InEdge inEdge;
    private OutEdge outEdge;

    @BeforeEach
    public void setup() {
        transition = new Transition("T1");
        inEdge = new InEdge(5);  
        outEdge = new OutEdge(5);  
    }

    @Test
    public void testAddInEdge() {
        transition.addInEdge(inEdge);
        ArrayList<InEdge> inEdges = transition.getInEdgeList();
        assertNotNull(inEdges, "InEdgeList should not be null");
        assertEquals(1, inEdges.size(), "InEdgeList size should be 1");
        assertEquals(inEdge, inEdges.get(0), "Added InEdge should be in the InEdgeList");
    }

    @Test
    public void testAddOutEdge() {
        transition.addOutEdge(outEdge);
        ArrayList<OutEdge> outEdges = transition.getOutEdgeList();
        assertNotNull(outEdges, "OutEdgeList should not be null");
        assertEquals(1, outEdges.size(), "OutEdgeList size should be 1");
        assertEquals(outEdge, outEdges.get(0), "Added OutEdge should be in the OutEdgeList");
    }

    @Test
    public void testGetName() {
        assertEquals("T1", transition.getName(), "Transition name should be 'T1'");
    }

}
