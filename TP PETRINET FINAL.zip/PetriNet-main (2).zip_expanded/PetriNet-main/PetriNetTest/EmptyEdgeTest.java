package PetriNetTest;

import PetriNet.EmptyEdge;
import PetriNet.Place;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class EmptyEdgeTest {

    private EmptyEdge emptyEdge;
    private Place place;

    @BeforeEach
    void setUp() {
        place = new Place("P1", 5); // Creating a new place with 5 tokens
        emptyEdge = new EmptyEdge(3); // Creating a new empty edge with value 3
        emptyEdge.setPlace(place); // Setting associated place
    }

    @Test
    void testTrigger() {
        emptyEdge.trigger();
        assertEquals(0, place.getTokens(), "The place should have 0 tokens after triggering the empty edge");
    }

    @Test
    void testIsTriggerable() {
        assertTrue(emptyEdge.isTriggerable(), "The edge should be triggerable when there are tokens in the place");

        place = new Place("P2", 0); // Updating the place to have 0 tokens
        emptyEdge.setPlace(place); // Setting associated place with the updated place

        assertFalse(emptyEdge.isTriggerable(), "The edge should not be triggerable when there are no tokens in the place");
    }
}
