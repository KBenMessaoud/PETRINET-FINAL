package PetriNetTest;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import PetriNet.InEdge;
import PetriNet.OutEdge;
import PetriNet.Place;

import static org.junit.jupiter.api.Assertions.*;

public class PlaceTest {

    private Place place;
    private InEdge inEdge;
    private OutEdge outEdge;

    @BeforeEach
    public void setup() {
        place = new Place("P1", 5);
        inEdge = new InEdge(3);  // Assuming a constructor that accepts an integer value exists
        outEdge = new OutEdge(2);  // Same assumption as above
    }

    @Test
    public void testAddTokens() {
        place.add(5);
        assertEquals(10, place.getTokens(), "Tokens should be 10 after adding 5");
    }

    @Test
    public void testRemoveTokens() throws Exception {
        place.remove(3);
        assertEquals(2, place.getTokens(), "Tokens should be 2 after removing 3");
    }

    @Test
    public void testRemoveTokensException() {
        Exception exception = assertThrows(Exception.class, () -> {
            place.remove(6);
        });

        String expectedMessage = "Not enough tokens in this place";
        String actualMessage = exception.getMessage();
        assertTrue(actualMessage.contains(expectedMessage));
    }

    @Test
    public void testAddInEdge() {
        place.addInEdge(inEdge);
        assertTrue(place.getInEdgeList().contains(inEdge), "InEdge should be added to the list");
    }

    @Test
    public void testAddOutEdge() {
        place.addOutEdge(outEdge);
        assertTrue(place.getOutEdgeList().contains(outEdge), "OutEdge should be added to the list");
    }

    @Test
    public void testGetTokens() {
        assertEquals(5, place.getTokens(), "Initial tokens should be 5");
    }

    @Test
    public void testGetName() {
        assertEquals("P1", place.getName(), "Place name should be 'P1'");
    }

   
}
