package PetriNetTest;

import PetriNet.PetriNetImplements;
import PetriNet.Place;
import PetriNet.Transition;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

class PetriNetImplementsTest {

    private PetriNetImplements petriNet;
    private Place place;
    private Place place2;
    private Transition transition;
    private Transition transition2;

    @BeforeEach
    void setUp() {
        petriNet = new PetriNetImplements();
        place = new Place("P1", 5);
        place2 = new Place("P2", 5);
        transition = new Transition("T1");
        transition2 = new Transition("T2");
    }

    @Test
    void testAddPlace() {
        petriNet.add(place);
        assertEquals(1, petriNet.getAllPlaces().size(), "Should have one place");
        assertEquals("P1", petriNet.getAllPlaces().get(0).getName(), "Place name should be 'P1'");
    }

    @Test
    void testRemovePlace() {
        petriNet.add(place);
        petriNet.remove(place);
        assertEquals(0, petriNet.getAllPlaces().size(), "Should have no places after removal");
    }

    @Test
    void testAddTransition() {
        petriNet.add(transition);
        assertEquals(1, petriNet.getAllTransitions().size(), "Should have one transition");
        assertEquals("T1", petriNet.getAllTransitions().get(0).getName(), "Transition name should be 'T1'");
    }

    @Test
    void testRemoveTransition() {
        petriNet.add(transition);
        petriNet.remove(transition);
        assertEquals(0, petriNet.getAllTransitions().size(), "Should have no transitions after removal");
    }
//
    @Test
    void testFindPlaceByName() {
        petriNet.add(place);
        assertEquals("P1", petriNet.findPlaceByName("P1"), "Should find the place with name 'P1'");
        assertNull(petriNet.findPlaceByName("P2"), "Should not find a place with name 'P2'");
    }

    @Test
    void testFindTransitionByName() {
        petriNet.add(transition);
        assertEquals("T1", petriNet.findTransitionByName("T1"), "Should find the transition with name 'T1'");
        assertNull(petriNet.findTransitionByName("T2"), "Should not find a transition with name 'T2'");
    }

    @Test
    void testStep() throws Exception {
        petriNet.add(place);
        petriNet.add(place2);
        petriNet.add(transition);
        petriNet.addOutgoingArc(place, transition, 1);
        petriNet.addIncomingArc(transition, place2, 1);

        int initialTokens = place.getTokens();
        petriNet.step();

        int expectedTokens = initialTokens - 1; // This is a basic example, adjust based on your implementation
        assertEquals(expectedTokens, place.getTokens(), "Tokens should be updated after step()");
    }
}
