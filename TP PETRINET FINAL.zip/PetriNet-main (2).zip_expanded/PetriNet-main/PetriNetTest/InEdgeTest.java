package PetriNetTest;

import PetriNet.InEdge;
import PetriNet.Place;
import PetriNet.Transition;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

class InEdgeTest {

    private InEdge inEdge;
    private Place place;
    private Transition transition;

    @BeforeEach
    void setUp() {
        place = new Place("P1", 5); // Creating a new place with 5 tokens
        transition = new Transition("T1"); // Creating a new transition
        inEdge = new InEdge(3); // Creating a new incoming edge with value 3
        inEdge.setPlace(place); // Setting associated place
        inEdge.setTransition(transition); // Setting associated transition
    }

    @Test
    void testTrigger() {
        inEdge.trigger();
        assertEquals(8, place.getTokens(), "The place should have 8 tokens after triggering the edge");
    }

    @Test
    void testSetPlace() {
        Place newPlace = new Place("P2", 10); // Creating another place with 10 tokens
        inEdge.setPlace(newPlace); // Setting the new place as associated place
        assertEquals(newPlace, inEdge.getPlace(), "Associated place should be updated to the new place");
    }

    @Test
    void testSetTransition() {
        Transition newTransition = new Transition("T2"); // Creating another transition
        inEdge.setTransition(newTransition); // Setting the new transition as associated transition
        assertEquals(newTransition, inEdge.getTransition(), "Associated transition should be updated to the new transition");
    }

    @Test
    void testSetNullTransition() {
        inEdge.setTransition(null); // Setting null as associated transition
        assertNotNull(inEdge.getTransition(), "Associated transition should not be null");
    }
}
