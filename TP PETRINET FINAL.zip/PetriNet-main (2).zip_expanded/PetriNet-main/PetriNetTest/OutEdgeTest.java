package PetriNetTest;

import PetriNet.OutEdge;
import PetriNet.Place;
import PetriNet.Transition;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class OutEdgeTest {

    private OutEdge outEdge;
    private Place place;
    private Transition transition;

    @BeforeEach
    void setUp() {
        place = new Place("P1", 5); // Creating a new place with 5 tokens
        transition = new Transition("T1"); // Creating a new transition
        outEdge = new OutEdge(3); // Creating a new outgoing edge with value 3
        outEdge.setPlace(place); // Setting associated place
        outEdge.setTransition(transition); // Setting associated transition
    }

    @Test
    void testTrigger() {
        assertTrue(outEdge.isTriggerable(), "Edge should be triggerable as place has enough tokens");
        outEdge.trigger();
        assertEquals(2, place.getTokens(), "2 tokens should remain in the place after triggering the edge");
    }

    @Test
    void testIsNotTriggerable() {
        outEdge = new OutEdge(6); // Creating a new outgoing edge with value 6
        outEdge.setPlace(place); // Re-assigning the associated place with the same place object
        assertFalse(outEdge.isTriggerable(), "Edge should not be triggerable as place has not enough tokens");
    }

    @Test
    void testSetPlace() {
        Place newPlace = new Place("P2", 10); // Creating another place with 10 tokens
        outEdge.setPlace(newPlace); // Setting the new place as associated place
        assertEquals(newPlace, outEdge.getPlace(), "Associated place should be updated to the new place");
    }

    @Test
    void testSetTransition() {
        Transition newTransition = new Transition("T2"); // Creating another transition
        outEdge.setTransition(newTransition); // Setting the new transition as associated transition
        assertEquals(newTransition, outEdge.getTransition(), "Associated transition should be updated to the new transition");
    }
}
