# PetriNet
Implémentation d'un réseau de pétri en groupe de 3
